const fetch = require("node-fetch");

async function chatgptAI(question, system) {
    const OPENAI_API_KEY = global.config?.openaiApiKey || "";

    if (!OPENAI_API_KEY || OPENAI_API_KEY.startsWith("sk-proj-...")) {
        throw new Error("openaiApiKey belum diisi di index.js");
    }

    const response = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
            model: "gpt-4o-mini",
            input: [
                {
                    role: "system",
                    content: [{ type: "input_text", text: system || "You are a helpful assistant. Respond in the same language as the user." }]
                },
                {
                    role: "user",
                    content: [{ type: "input_text", text: question }]
                }
            ]
        })
    });

    if (!response.ok) {
        const errBody = await response.text();
        throw new Error(`OpenAI API error ${response.status}: ${errBody}`);
    }

    const data = await response.json();

    const text =
        data.output_text ||
        data.output?.flatMap(v => v.content || [])
            ?.find(v => v.type === "output_text")?.text ||
        "";

    if (!text) throw new Error("Empty response from ChatGPT");
    return text;
}

module.exports = {
    name: "ChatGPT",
    desc: "AI chat menggunakan model ChatGPT dari OpenAI",
    category: "Openai",
    parameters: {
        apikey: {
            type: "string",
            example: "123",
            value: "",
            required: true
        },
        question: {
            type: "string",
            example: "Siapa kamu?",
            value: "",
            required: true
        },
        system: {
            type: "string",
            example: "Kamu adalah asisten yang helpful",
            value: "",
            required: false
        }
    },
    path: "/api/ai/chatgpt",

    async run(req, res) {
        const { question, apikey, system } = req.query;

        if (!question) return res.json({ status: false, error: "Parameter 'question' wajib diisi" });
        if (!apikey || !global.apikey?.includes(apikey)) {
            return res.json({ status: false, error: "API key tidak valid" });
        }

        try {
            const systemPrompt = system || "You are a helpful assistant. Respond in the same language as the user.";
            const result = await chatgptAI(question, systemPrompt);
            res.json({ status: true, result });
        } catch (err) {
            res.status(500).json({ status: false, error: err.message });
        }
    }
};
