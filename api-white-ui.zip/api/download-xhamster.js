const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const cheerio = require('cheerio');

/**
 * @typedef {Object} VideoSource
 * @property {string} quality
 * @property {string} url
 */

// ============================
//   HELPER: Ultra-Fast Source Extractor
// ============================
function fastParseSources(html) {
    const videos = [];
    // Pattern untuk menangkap URL mp4 dan label kualitas dalam objek JS/JSON
    const patterns = [
        /["'](videoUrl|url|file)["']\s*:\s*["'](https?:\/\/[^"']+\.mp4[^"']*)["']/g,
        /["'](label|quality|format)["']\s*:\s*["']([^"']+)["']/g
    ];

    // Ekstraksi langsung menggunakan regex pada seluruh block script (Overclocked Speed)
    const mp4Matches = [...html.matchAll(/["'](https?:\/\/[^"']+\.mp4[^"']*)["']/g)];
    
    mp4Matches.forEach(match => {
        const link = match[1].replace(/\\/g, '');
        if (!link.includes('thumb') && !videos.some(v => v.url === link)) {
            // Mencari label terdekat (biasanya ada string kualitas seperti 720p di dekatnya)
            let quality = 'unknown';
            const context = html.substring(match.index - 100, match.index + 100);
            const qualityMatch = context.match(/(\d{3,4}p|HD|SD|quality["']\s*:\s*["'](\d+))/);
            if (qualityMatch) quality = qualityMatch[2] || qualityMatch[1];
            
            videos.push({ quality, url: link.split('?')[0] });
        }
    });

    return videos;
}

function extractVideoId(url) {
    const match = url.match(/(?:videos\/|xembed\.php\?video=)([a-z0-9]+)/i);
    if (match) return match[1].split('-').pop(); // Handle slug format
    return null;
}

// ============================
//      CORE SCRAPER ENGINE
// ============================
async function xhamsterDl(url) {
    const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://xhamster.com/',
        'Cookie': 'age_verified=1' // Bypass age verification wall
    };

    try {
        const videoId = extractVideoId(url);
        if (!videoId) throw new Error("Invalid xHamster URL ID");

        // Prioritas 1: Ambil dari Embed Page (Data lebih bersih & minim proteksi)
        const embedUrl = `https://xhamster.com/xembed.php?video=${videoId}`;
        const res = await fetch(embedUrl, { headers });
        const html = await res.text();
        
        let videos = fastParseSources(html);

        // Prioritas 2: Fallback ke Main Page jika Embed gagal
        if (videos.length === 0) {
            const mainRes = await fetch(url, { headers });
            const mainHtml = await mainRes.text();
            videos = fastParseSources(mainHtml);
        }

        if (videos.length === 0) throw new Error("Video sources not found or geo-blocked");

        const $ = cheerio.load(html);
        const title = $('title').text().replace(' - xHamster.com', '').trim() || "xHamster Video";
        const thumbnail = $('link[rel="image_src"]').attr('href') || null;

        // Sort & Clean up
        const uniqueVideos = videos.filter((v, i, a) => a.findIndex(t => t.url === v.url) === i);
        uniqueVideos.sort((a, b) => parseInt(b.quality) - parseInt(a.quality));

        return {
            title,
            thumbnail,
            videoId,
            source: url,
            videos: uniqueVideos
        };
    } catch (err) {
        return { error: err.message };
    }
}

// ============================
//      ENDPOINT EXPRESS
// ============================
module.exports = {
    name: "Xhamster",
    desc: "Refactored & Overclocked Xhamster Downloader",
    category: "Downloader",
    parameters: { apikey: { type: "string" }, url: { type: "string" } },
    path: "/download/xhamster",
    async run(req, res) {
        const { apikey, url } = req.query;
        
        // Security check
        if (!apikey || !global.apikey.includes(apikey)) {
            return res.status(403).json({ status: false, error: "Access Denied: Invalid Apikey" });
        }
        if (!url) return res.status(400).json({ status: false, error: "Missing Target URL" });

        try {
            const result = await xhamsterDl(url);
            if (result.error) return res.status(404).json({ status: false, error: result.error });

            return res.status(200).json({
                status: true,
                creator: 'Demox_Ai’CvA057xp',
                result
            });
        } catch (error) {
            return res.status(500).json({ status: false, error: "Internal Server Error" });
        }
    }
};