const fetch = require("node-fetch");

async function claudeAI(question, system) {
    const CLAUDE_API_KEY = global.config?.claudeApiKey || "";

    if (!CLAUDE_API_KEY || CLAUDE_API_KEY.startsWith("sk-ant-api03-...")) {
        throw new Error("claudeApiKey belum diisi di index.js");
    }

    const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "x-api-key": CLAUDE_API_KEY,
            "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
            model: "claude-sonnet-4-20250514",
            max_tokens: 8096,
            system: system,
            messages: [{ role: "user", content: question }]
        })
    });

    if (!response.ok) {
        const errBody = await response.text();
        throw new Error(`Anthropic API error ${response.status}: ${errBody}`);
    }

    const data = await response.json();
    const text = data.content?.find(b => b.type === "text")?.text || "";
    if (!text) throw new Error("Empty response from Claude");
    return text;
}

module.exports = {
    name: "Claude AI",
    desc: "AI chat menggunakan model Claude dari Anthropic",
    category: "Openai",
    parameters: {
        apikey: {
            type: "string",
            example: "your_api_key_here",
            value: "",
            required: true
        },
        question: {
            type: "string",
            example: "Siapa kamu?",
            value: "",
            required: true
        },
        system: {
            type: "string",
            example: "Kamu adalah asisten yang helpful",
            value: "",
            required: false
        }
    },
    path: "/api/ai/claude",

    async run(req, res) {
        const { question, apikey, system } = req.query;

        if (!question) return res.json({ status: false, error: "Parameter 'question' wajib diisi" });
        if (!apikey || !global.apikey?.includes(apikey)) {
            return res.json({ status: false, error: "API key tidak valid" });
        }

        try {
            const systemPrompt = system || "You are a helpful assistant. Respond in the same language as the user.";
            const result = await claudeAI(question, systemPrompt);
            res.json({ status: true, result });
        } catch (err) {
            res.status(500).json({ status: false, error: err.message });
        }
    }
};
