const cloudscraper = require("cloudscraper");
const cheerio = require("cheerio");

// cloudscraper otomatis handle Cloudflare JS challenge + cookies
const scraper = cloudscraper.defaults({
  headers: {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8"
  },
  timeout: 20000
});

function get(url, referer) {
  return new Promise((resolve, reject) => {
    const opts = { uri: url };
    if (referer) opts.headers = { Referer: referer };
    scraper.get(opts, (err, res, body) => {
      if (err) return reject(err);
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      resolve(body);
    });
  });
}

async function fetchNekopoiV1(query) {
  const searchUrl = `https://nekopoi.care/search/${encodeURIComponent(query)}`;
  const html = await get(searchUrl);
  const $ = cheerio.load(html);
  const results = [];

  $("div.result ul li").each((i, li) => {
    const el = $(li);
    const aTag = el.find("h2 > a");
    const title = aTag.text().trim();
    const link = aTag.attr("href");
    let duration = null;
    el.find("div.desc p").each((_, p) => {
      const pText = $(p).text();
      if (/Duration\s*:/i.test(pText) || /Durasi\s*:/i.test(pText)) {
        duration = pText.replace(/Duration\s*:\s*/i, "").replace(/Durasi\s*:\s*/i, "").trim();
        return false;
      }
    });
    if (title && link) results.push({ title, link, duration });
  });

  for (let item of results) {
    try {
      const detailHtml = await get(item.link, searchUrl);
      const $$ = cheerio.load(detailHtml);
      const streamIds = ["#stream3", "#stream2", "#stream1"];
      let videoSrc = null;
      for (const id of streamIds) {
        const iframe = $$(id + " iframe.vids");
        if (iframe.length) {
          videoSrc = iframe.attr("src");
          if (videoSrc) break;
        }
      }
      item.videoSrc = videoSrc || null;
    } catch {
      item.videoSrc = null;
    }
  }

  return results;
}

module.exports = {
  name: "Nekopoi",
  desc: "Search vidio dari Nekopoi.care",
  category: "Search",
  parameters: {
    apikey: { type: "string" },
    q: { type: "string" }
  },
  path: "/search/nekopoi",
  async run(req, res) {
    const { apikey, q } = req.query;

    if (!global.apikey.includes(apikey)) {
      return res.json({ status: false, error: "Apikey invalid" });
    }

    if (!q) {
      return res.json({ status: false, error: "Query is required" });
    }

    try {
      const results = await fetchNekopoiV1(q);
      if (!results.length) {
        return res.status(200).json({ status: false, error: "Tidak ada hasil ditemukan" });
      }
      res.status(200).json({ status: true, result: results });
    } catch (error) {
      res.status(500).json({ status: false, error: error.message });
    }
  }
};
