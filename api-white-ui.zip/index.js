const express = require('express');
const chalk = require('chalk');
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const axios = require('axios');
const multer = require('multer');
const { formidable } = require('formidable');

// ============================================================
//  ✦  KONFIGURASI UTAMA — Edit semua pengaturan di sini  ✦
// ============================================================
const config = {
  port: process.env.PORT || 4000,
  name: "Elfaria-AI Api",
  description: "Elfaria-AI Api is a simple and lightweight REST API built with Node.js.",
  creator: "Zenvy",
  profile: {
    name: "Zenvy",
    handle: "@zenvy",
    bio: "I'm just a newbie who longs for elfaria.",
    avatarUrl: "https://img2.pixhost.to/images/7388/717741811_alip-1776945040433.jpg",
    verified: true,
    bannerVideoUrl: "https://a.top4top.io/m_3765bs3v91.mp4",
    spotifyPlaylistId: "37i9dQZF1DXcBWIGoYBM5M",
    interests: [
      { emoji: "🖥️", label: "Coder" },
      { emoji: "🎮", label: "Game"  },
      { emoji: "🎵", label: "Music" }
    ]
  },
  linkWhatsapp:  "https://wa.me/6285189656447",
  linkChannel:   "https://t.me/zenvyreal",
  linkGithub:    "https://github.com/",
  linkYoutube:   "https://www.youtube.com/@",
  linkTelegram:  "https://t.me/zenvyreal",
  linkInstagram: "https://instagram.com/zenvymarket.ig",
  linkTiktok:    "https://zenvy.web.id",
  contact: {
    email:         "storeinexus@gmail.com",
    emailLink:     "mailto:storeinexus@gmail.com",
    whatsapp:      "+62 851 8965 6447",
    whatsappLink:  "https://wa.me/6285189656447",
    whatsappValue: "+6285189656447",
    telegram:      "@zenvyreal",
    telegramLink:  "https://t.me/zenvyreal",
    instagram:     "@zenvymarket.ig",
    instagramLink: "https://instagram.com/zenvymarket.ig"
  },
  location: {
    mapEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25924.81!2d139.69!3d35.69!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60188cd0d6597665%3A0x10d49c5c4dd3c1eb!2sShinjuku%20City%2C%20Tokyo!5e0!3m2!1sen!2sjp!4v1",
    mapLink:     "https://maps.google.com/?q=Shinjuku+City+Tokyo",
    label:       "Somewhere in the Internet"
  },
  navItems: [
    { href: "/kontak",      icon: "fas fa-envelope",          color: "blue",   title: "Contact",      subtitle: "Contact Help Center" },
    { href: "/produk",      icon: "fas fa-box-open",          color: "purple", title: "Produk",       subtitle: "View available products" },
    { href: "/tools",       icon: "fas fa-tools",             color: "pink",   title: "Tools",        subtitle: "Free Downloader & Web Utilities" },
    { href: "/gudang-script",icon: "fas fa-code",             color: "green",  title: "Gudang Script",subtitle: "Free script warehouse" },
    { href: "/donasi",      icon: "fas fa-hand-holding-heart",color: "yellow", title: "Donasi",       subtitle: "Support our project voluntarily" }
  ],
  community: {
    grupChatSubtitle:  "Gabung ke grup support & sharing",
    grupChatTelegram:  "https://t.me/zenvyreal",
    grupChatWhatsapp:  "https://wa.me/6285189656447",
    channelInfo:       "https://t.me/zenvyreal",
    channelSubtitle:   "Dapatkan notifikasi update penting"
  },
  footerCopyright: "© 2025 Zenvy Official. All Right Reserved",
  apiKeys: ["123","1"],
  openaiApiKey: "sk-proj-...",
  claudeApiKey: "sk-ant-api03-...",
  googleApiKey: "AIzaSy...",
};

// ============================================================
//  ✦  PANEL OWNER — Kredensial Login  ✦
// ============================================================
const PANEL = {
  username: "Zenvy",
  password: "004",
  sessions: new Set()
};

function generateToken() {
  return Math.random().toString(36).substring(2,15) + Date.now().toString(36);
}

function requirePanelAuth(req, res, next) {
  const token = req.headers['x-panel-token'];
  if (token && PANEL.sessions.has(token)) return next();
  return res.status(401).json({ success: false, message: 'Unauthorized. Silakan login terlebih dahulu.' });
}
// ============================================================

const overridePath = path.join(__dirname, 'data/override.json');
if (fs.existsSync(overridePath)) {
  try {
    const override = JSON.parse(fs.readFileSync(overridePath, 'utf-8'));
    Object.assign(config, override);
    console.log(chalk.bgHex('#ADD8E6').hex('#333').bold(' Override settings loaded ✓ '));
  } catch(e) { console.error(chalk.red('Failed to load override.json:'), e.message); }
}

const produkPath = path.join(__dirname, 'data/produk.json');
let produkData = null;
if (fs.existsSync(produkPath)) {
  try {
    produkData = JSON.parse(fs.readFileSync(produkPath, 'utf-8'));
    console.log(chalk.bgHex('#ADD8E6').hex('#333').bold(' Produk data loaded ✓ '));
  } catch(e) { console.error(chalk.red('Failed to load produk.json:'), e.message); }
}

global.config = config;
global.apikey = config.apiKeys;

const app = express();
const upload = multer();

app.enable("trust proxy");
app.set("json spaces", 2);
app.use(express.static(path.join(__dirname, 'src')));
app.use(express.json());
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));
app.use(cors());

global.getBuffer = async (url, options = {}) => {
  try {
    const res = await axios({ method:'get', url, headers:{'DNT':1,'Upgrade-Insecure-Request':1}, ...options, responseType:'arraybuffer' });
    return res.data;
  } catch(err) { return err; }
};

global.fetchJson = async (url, options = {}) => {
  try {
    const res = await axios({ method:'GET', url, headers:{'User-Agent':'Mozilla/5.0'}, ...options });
    return res.data;
  } catch(err) { return err; }
};

app.use((req, res, next) => {
  const originalJson = res.json;
  res.json = function(data) {
    if (data && typeof data === 'object') {
      return originalJson.call(this, { status: data.status, creator: config.creator || "Created Using Zenvy", ...data });
    }
    return originalJson.call(this, data);
  };
  next();
});

let totalRoutes = 0;
let rawEndpoints = {};
const apiFolder = path.join(__dirname, './api');

function convertParametersForFrontend(parameters) {
  if (!parameters) return {};
  const converted = {};
  for (const [paramName, paramConfig] of Object.entries(parameters)) {
    converted[paramName] = {
      type: paramConfig.type || "string",
      ...(paramConfig.required  !== undefined && { required: paramConfig.required }),
      ...(paramConfig.example   && { example: paramConfig.example }),
      ...(paramConfig.value     && { value: paramConfig.value }),
      ...(paramConfig.selection && { selection: paramConfig.selection })
    };
  }
  return converted;
}

const register = (ep, file) => {
  if (ep && ep.name && (ep.desc || ep.description) && ep.category && ep.path && typeof ep.run === "function") {
    const cleanPath = ep.path.split("?")[0];
    const method = ep.method ? ep.method.toLowerCase() : 'get';
    if (method === 'post') {
      app.post(cleanPath, upload.any(), (req, res, next) => { ep.run(req, res, next); });
    } else {
      app.get(cleanPath, (req, res, next) => { ep.run(req, res, next); });
    }
    if (!rawEndpoints[ep.category]) rawEndpoints[ep.category] = [];
    rawEndpoints[ep.category].push({
      name: ep.name, description: ep.description || ep.desc || null, path: ep.path,
      method: ep.method || 'GET', parameters: convertParametersForFrontend(ep.parameters),
      ...(ep.innerDesc ? { innerDesc: ep.innerDesc } : {}),
      ...(ep.body      ? { body: ep.body }           : {})
    });
    totalRoutes++;
    console.log(chalk.bgHex('#FFFF99').hex('#333').bold(` Loaded Route: ${file} → ${ep.name} (${method.toUpperCase()}) `));
  }
};

fs.readdirSync(apiFolder).forEach((file) => {
  const filePath = path.join(apiFolder, file);
  if (path.extname(file) === '.js') {
    try {
      delete require.cache[require.resolve(filePath)];
      const routeModule = require(filePath);
      if (Array.isArray(routeModule)) routeModule.forEach(ep => register(ep, file));
      else if (routeModule.endpoint) register(routeModule.endpoint, file);
      else if (typeof routeModule === "function") routeModule(app);
      else register(routeModule, file);
    } catch(err) { console.error(chalk.red(`Error loading ${file}:`), err.message); }
  }
});

console.log(chalk.bgHex('#90EE90').hex('#333').bold(' Load Complete! ✓ '));
console.log(chalk.bgHex('#90EE90').hex('#333').bold(` Total Routes Loaded: ${totalRoutes} `));

function buildCategories() {
  return Object.keys(rawEndpoints).sort((a,b) => a.localeCompare(b)).map(category => ({
    name: category,
    items: rawEndpoints[category].sort((a,b) => a.name.localeCompare(b.name)).map(endpoint => ({
      name: endpoint.name, method: endpoint.method || 'GET', path: endpoint.path,
      description: endpoint.description || endpoint.desc, parameters: endpoint.parameters || {}
    }))
  }));
}

app.get('/api/data', (req, res) => {
  res.json({ success: true, data: { categories: buildCategories() }, message: `Loaded ${totalRoutes} endpoints` });
});

app.get('/settings', (req, res) => {
  const categories = buildCategories();
  res.json({
    name: config.name, description: config.description, creator: config.creator,
    profile: config.profile, linkWhatsapp: config.linkWhatsapp, linkChannel: config.linkChannel,
    linkGithub: config.linkGithub, linkYoutube: config.linkYoutube, linkTelegram: config.linkTelegram,
    linkInstagram: config.linkInstagram, linkTiktok: config.linkTiktok, contact: config.contact,
    location: config.location, navItems: config.navItems, community: config.community,
    footerCopyright: config.footerCopyright, categories,
    metadata: { totalEndpoints: totalRoutes, totalCategories: categories.length, lastUpdated: new Date().toISOString() }
  });
});

// ─────────────────────────────────────────────────────────
//  PANEL OWNER ROUTES
// ─────────────────────────────────────────────────────────
app.get('/panel', (req, res) => res.sendFile(path.join(__dirname, 'src/panel.html')));

app.post('/panel/login', (req, res) => {
  const { username, password } = req.body;
  if (username === PANEL.username && password === PANEL.password) {
    const token = generateToken();
    PANEL.sessions.add(token);
    return res.json({ success: true, token });
  }
  return res.json({ success: false, message: 'Username atau password salah!' });
});

app.post('/panel/logout', requirePanelAuth, (req, res) => {
  PANEL.sessions.delete(req.headers['x-panel-token']);
  res.json({ success: true, message: 'Logout berhasil.' });
});

app.get('/panel/get-settings', requirePanelAuth, (req, res) => {
  res.json({
    success: true,
    config: {
      name: config.name, description: config.description, creator: config.creator,
      profile: config.profile, linkWhatsapp: config.linkWhatsapp, linkChannel: config.linkChannel,
      linkGithub: config.linkGithub, linkYoutube: config.linkYoutube, linkTelegram: config.linkTelegram,
      linkInstagram: config.linkInstagram, linkTiktok: config.linkTiktok, contact: config.contact,
      location: config.location, community: config.community, footerCopyright: config.footerCopyright,
      apiKeys: config.apiKeys,
    }
  });
});

app.post('/panel/save-settings', requirePanelAuth, (req, res) => {
  try {
    const allowed = ['name','description','creator','profile','linkWhatsapp','linkChannel',
      'linkGithub','linkYoutube','linkTelegram','linkInstagram','linkTiktok',
      'contact','location','community','footerCopyright','apiKeys'];
    const updates = {};
    for (const key of allowed) { if (req.body[key] !== undefined) updates[key] = req.body[key]; }
    Object.assign(config, updates);
    global.config = config;
    global.apikey = config.apiKeys;
    const dataDir = path.join(__dirname, 'data');
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    let existing = {};
    if (fs.existsSync(overridePath)) { try { existing = JSON.parse(fs.readFileSync(overridePath,'utf-8')); } catch(e){} }
    Object.assign(existing, updates);
    fs.writeFileSync(overridePath, JSON.stringify(existing, null, 2));
    res.json({ success: true, message: 'Pengaturan berhasil disimpan!' });
  } catch(e) { res.status(500).json({ success: false, message: 'Gagal menyimpan: ' + e.message }); }
});

app.get('/panel/get-produk', requirePanelAuth, (req, res) => {
  if (produkData) return res.json({ success: true, produk: produkData });
  res.json({ success: true, produk: [] });
});

app.post('/panel/save-produk', requirePanelAuth, (req, res) => {
  try {
    const { produk } = req.body;
    if (!Array.isArray(produk)) return res.status(400).json({ success: false, message: 'Data produk tidak valid.' });
    const dataDir = path.join(__dirname, 'data');
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
    fs.writeFileSync(produkPath, JSON.stringify(produk, null, 2));
    produkData = produk;
    res.json({ success: true, message: 'Data produk berhasil disimpan!' });
  } catch(e) { res.status(500).json({ success: false, message: 'Gagal menyimpan produk: ' + e.message }); }
});

app.get('/api/produk', (req, res) => {
  if (produkData) return res.json({ success: true, produk: produkData });
  res.json({ success: true, produk: null });
});
// ─────────────────────────────────────────────────────────

app.get('/',       (req, res) => res.sendFile(path.join(__dirname, 'src/index.html')));
app.get('/kontak',  (req, res) => res.sendFile(path.join(__dirname, 'src/kontak.html')));
app.get('/tools',   (req, res) => res.sendFile(path.join(__dirname, 'src/docs.html')));
app.get('/docs',   (req, res) => res.sendFile(path.join(__dirname, 'src/docs.html')));
app.get('/produk', (req, res) => res.sendFile(path.join(__dirname, 'src/produk.html')));
app.get('/donasi', (req, res) => res.sendFile(path.join(__dirname, 'src/donasi.html')));

app.get('/health', (req, res) => res.json({
  status: 'healthy', serverTime: new Date().toISOString(), uptime: process.uptime(), endpoints: totalRoutes
}));

app.listen(config.port, () => {
  console.log(chalk.bgHex('#90EE90').hex('#333').bold(` Server is running on port ${config.port} `));
  console.log(chalk.cyan(`  Homepage:    http://localhost:${config.port}`));
  console.log(chalk.cyan(`  Settings:    http://localhost:${config.port}/settings`));
  console.log(chalk.magenta(`  Owner Panel: http://localhost:${config.port}/panel`));
});

module.exports = app;
